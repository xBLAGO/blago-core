# BLAGO Process
1. User defines a NEED (e.g. MacBook).
2. Bot sets parameters and price.
3. NFT is minted. xBLAGO tokens are calculated and issued.
4. Tokens go to DEX. NFT goes to user.
5. Upon purchase, real assets go to the user. NFT to buyer. Tokens burned.