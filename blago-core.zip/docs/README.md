# BLAGO Core
Core smart contracts and infrastructure for the BLAGO decentralized network on TON.

## Overview
BLAGO is a decentralized network that digitizes human needs as NFTs and finances them through xBLAGO tokens tied to Bitcoin's rate.